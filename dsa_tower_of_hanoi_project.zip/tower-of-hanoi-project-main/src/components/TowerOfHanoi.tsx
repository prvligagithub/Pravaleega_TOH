import { useState, useEffect, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, RotateCcw, FastForward } from "lucide-react";
import { toast } from "sonner";
import ThemeToggle from "@/components/ThemeToggle";

interface Move {
  from: number;
  to: number;
  disk: number;
}

interface TowerState {
  towers: number[][];
  moveCount: number;
  totalMoves: number;
}

const TowerOfHanoi = () => {
  const [numDisks, setNumDisks] = useState(4);
  const [towers, setTowers] = useState<number[][]>([[], [], []]);
  const [moves, setMoves] = useState<Move[]>([]);
  const [currentMoveIndex, setCurrentMoveIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState([500]); // milliseconds - increased range for faster solving
  const [isAnimating, setIsAnimating] = useState(false);
  const [activeDisk, setActiveDisk] = useState<number | null>(null);

  // Calculate minimum moves required: 2^n - 1
  const minMoves = Math.pow(2, numDisks) - 1;

  // Generate Tower of Hanoi solution moves
  const generateMoves = useCallback((n: number, from: number, to: number, aux: number): Move[] => {
    if (n === 1) {
      return [{ from, to, disk: 1 }];
    }
    
    const moves: Move[] = [];
    moves.push(...generateMoves(n - 1, from, aux, to));
    moves.push({ from, to, disk: n });
    moves.push(...generateMoves(n - 1, aux, to, from));
    
    return moves;
  }, []);

  // Initialize the puzzle
  const initializePuzzle = useCallback(() => {
    const initialTowers: number[][] = [[], [], []];
    // Place all disks on the first tower (largest to smallest from bottom to top)
    for (let i = numDisks; i >= 1; i--) {
      initialTowers[0].push(i);
    }
    
    setTowers(initialTowers);
    setMoves(generateMoves(numDisks, 0, 2, 1));
    setCurrentMoveIndex(0);
    setIsPlaying(false);
    setActiveDisk(null);
    toast.success(`Puzzle initialized with ${numDisks} disks. ${minMoves} moves required.`);
  }, [numDisks, minMoves, generateMoves]);

  // Execute a single move with animation
  const executeMove = useCallback(async (move: Move) => {
    setIsAnimating(true);
    setActiveDisk(move.disk);

    // Create new towers state
    const newTowers = towers.map(tower => [...tower]);
    
    // Find the actual disk to move (top disk from source tower)
    const diskToMove = newTowers[move.from].pop();
    
    if (diskToMove !== undefined) {
      // Add animation delay for smooth transition
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Place disk on destination tower
      newTowers[move.to].push(diskToMove);
      setTowers(newTowers);
      
      // Wait for animation to complete
      await new Promise(resolve => setTimeout(resolve, 300));
    }

    setActiveDisk(null);
    setIsAnimating(false);
  }, [towers]);

  // Auto-play functionality
  useEffect(() => {
    if (!isPlaying || currentMoveIndex >= moves.length || isAnimating) return;

    const timer = setTimeout(async () => {
      await executeMove(moves[currentMoveIndex]);
      setCurrentMoveIndex(prev => prev + 1);
    }, speed[0]);

    return () => clearTimeout(timer);
  }, [isPlaying, currentMoveIndex, moves, speed, executeMove, isAnimating]);

  // Check if puzzle is solved
  useEffect(() => {
    if (towers[2].length === numDisks && currentMoveIndex > 0) {
      setIsPlaying(false);
      toast.success(`🎉 Puzzle solved in ${currentMoveIndex} moves!`);
    }
  }, [towers, numDisks, currentMoveIndex]);

  // Initialize puzzle on component mount or disk count change
  useEffect(() => {
    initializePuzzle();
  }, [initializePuzzle]);

  const handlePlay = () => {
    if (currentMoveIndex >= moves.length) {
      toast.info("Puzzle already completed. Reset to play again.");
      return;
    }
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setIsPlaying(false);
    initializePuzzle();
  };

  const handleStepForward = async () => {
    if (currentMoveIndex < moves.length && !isAnimating) {
      setIsPlaying(false);
      await executeMove(moves[currentMoveIndex]);
      setCurrentMoveIndex(prev => prev + 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-background p-4 sm:p-8 transition-all duration-300">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header with Theme Toggle */}
        <div className="flex justify-between items-start">
          <div className="text-center flex-1 space-y-4 animate-fade-in-up">
            <h1 className="text-4xl sm:text-6xl font-bold bg-gradient-primary bg-clip-text text-transparent font-inter tracking-tight">
              Tower of Hanoi
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto font-medium leading-relaxed">
              Experience the ancient puzzle with elegant animations. 
              Move all disks from the left tower to the right tower following the classical rules.
            </p>
          </div>
          <div className="flex-shrink-0 ml-4">
            <ThemeToggle />
          </div>
        </div>

        {/* Controls */}
        <Card className="bg-gradient-card border-border shadow-medium p-6 animate-fade-in-up">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
            {/* Number of Disks */}
            <div className="space-y-2">
              <Label htmlFor="disks" className="text-foreground font-semibold">
                Number of Disks
              </Label>
              <Input
                id="disks"
                type="number"
                min="3"
                max="8"
                value={numDisks}
                onChange={(e) => setNumDisks(Math.max(3, Math.min(8, parseInt(e.target.value) || 3)))}
                className="bg-background border-border font-mono text-center text-lg font-semibold"
                disabled={isPlaying}
              />
              <p className="text-sm text-muted-foreground font-mono">
                Min moves: <span className="font-semibold text-primary">{minMoves}</span>
              </p>
            </div>

            {/* Speed Control */}
            <div className="space-y-2">
              <Label className="text-foreground font-semibold">
                Animation Speed
              </Label>
              <Slider
                value={speed}
                onValueChange={setSpeed}
                max={1500}
                min={50}
                step={25}
                className="w-full"
                disabled={isAnimating}
              />
              <p className="text-sm text-muted-foreground font-mono">
                {speed[0]}ms delay ({((1550 - speed[0]) / 75).toFixed(1)}x speed)
              </p>
            </div>

            {/* Progress */}
            <div className="space-y-2">
              <Label className="text-foreground font-semibold">
                Progress
              </Label>
              <div className="text-2xl font-mono font-bold text-primary">
                {currentMoveIndex} / {moves.length}
              </div>
              <div className="w-full bg-secondary rounded-full h-3 overflow-hidden">
                <div 
                  className="bg-gradient-primary h-3 rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${(currentMoveIndex / moves.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Control Buttons */}
            <div className="flex gap-2">
              <Button
                onClick={handlePlay}
                disabled={isAnimating}
                variant="default"
                size="icon"
                className="bg-gradient-primary hover:opacity-90"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </Button>
              <Button
                onClick={handleStepForward}
                disabled={isAnimating || currentMoveIndex >= moves.length}
                variant="secondary"
                size="icon"
              >
                <FastForward className="w-4 h-4" />
              </Button>
              <Button
                onClick={handleReset}
                disabled={isAnimating}
                variant="outline"
                size="icon"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>

        {/* Tower Visualization */}
        <TowerVisualization 
          towers={towers} 
          numDisks={numDisks} 
          activeDisk={activeDisk}
        />
      </div>
    </div>
  );
};

// Tower Visualization Component
interface TowerVisualizationProps {
  towers: number[][];
  numDisks: number;
  activeDisk: number | null;
}

const TowerVisualization = ({ towers, numDisks, activeDisk }: TowerVisualizationProps) => {
  const getDiskColor = (diskSize: number) => {
    const colors = [
      'bg-disk-1', 'bg-disk-2', 'bg-disk-3', 'bg-disk-4',
      'bg-disk-5', 'bg-disk-6', 'bg-disk-7', 'bg-disk-8'
    ];
    return colors[diskSize - 1] || 'bg-primary';
  };

  const getDiskWidth = (diskSize: number) => {
    const baseWidth = 60; // Smallest disk width in px
    const increment = 20; // Width increase per disk size
    return baseWidth + (diskSize - 1) * increment;
  };

  return (
    <Card className="bg-gradient-card border-border shadow-medium p-8 animate-fade-in-up">
      <div className="flex justify-center items-end space-x-8 sm:space-x-16 min-h-[400px]">
        {towers.map((tower, towerIndex) => (
          <div key={towerIndex} className="flex flex-col items-center space-y-4">
            {/* Tower Label */}
            <div className="text-lg font-bold text-foreground tracking-wide">
              Tower {towerIndex + 1}
            </div>
            
            {/* Tower Structure */}
            <div className="relative flex flex-col-reverse items-center">
              {/* Base */}
              <div className="w-48 h-4 bg-base rounded-lg shadow-soft" />
              
              {/* Rod */}
              <div className="w-3 bg-rod rounded-t-full shadow-soft" style={{ height: `${numDisks * 25 + 50}px` }} />
              
              {/* Disks */}
              <div className="absolute bottom-4 flex flex-col-reverse items-center">
                {tower.map((diskSize, diskIndex) => (
                  <div
                    key={`${towerIndex}-${diskIndex}-${diskSize}`}
                    className={`
                      h-6 rounded-lg shadow-soft transition-all duration-700 ease-out
                      ${getDiskColor(diskSize)}
                      ${activeDisk === diskSize ? 'animate-pulse-glow scale-105 brightness-125' : ''}
                      hover:brightness-110 cursor-pointer
                    `}
                    style={{
                      width: `${getDiskWidth(diskSize)}px`,
                      marginBottom: diskIndex === 0 ? '0px' : '2px',
                    }}
                  />
                ))}
              </div>
            </div>
            
            {/* Tower Info */}
            <div className="text-sm text-muted-foreground font-medium">
              {tower.length} disk{tower.length !== 1 ? 's' : ''}
            </div>
          </div>
        ))}
      </div>
      
      {/* Rules */}
      <div className="mt-8 p-6 bg-secondary/30 border border-border/50 rounded-xl">
        <h3 className="font-bold text-foreground mb-3 text-lg">Rules:</h3>
        <ul className="text-sm text-muted-foreground space-y-2 font-medium">
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></span>
            <span>Move all disks from Tower 1 to Tower 3</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></span>
            <span>Only one disk can be moved at a time</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></span>
            <span>A larger disk cannot be placed on top of a smaller disk</span>
          </li>
        </ul>
      </div>
    </Card>
  );
};

export default TowerOfHanoi;