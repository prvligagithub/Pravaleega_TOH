import TowerOfHanoi from "@/components/TowerOfHanoi";

const Index = () => {
  return <TowerOfHanoi />;
};

export default Index;
